# Roadmap Page Design

_Started 2026-05-17 17:13 UTC_

---

## User

i have uploaded a picture of the website roadmap, and a picture of a roadmap. create a new page for the roadmap merging these two

## Assistant

_[tool: view_image]_

_[tool: view_image]_

_[tool: list_files]_

_[tool: list_files]_

_[tool: list_files]_

_[tool: read_file]_

_[tool: read_file]_

_[tool: read_file]_

_[tool: list_files]_

_[tool: read_file]_

_[tool: read_file]_

_[tool: copy_files]_

_[tool: copy_starter_component]_

Got it — I have a clear picture. The screenshot is the FitPath Running path detail (linear stage list), and you want to merge it with the winding-road-with-pins metaphor. I'll build a full-bleed prototype that replaces the stacked task list with a serpentine road snaking down the page, pins at each stage, and the same tap-to-complete + confetti behavior.

Let me first copy the design system tokens, then build it.

_[tool: write_file]_

Now I'll write the main roadmap page. The design: a vertical serpentine road snaking down the page with stages as map pins, each connecting to a side card with stage details. Tapping a pin toggles completion (same confetti behavior as the original TaskList).

_[tool: write_file]_

Now the main Roadmap component. The road is a serpentine SVG bezier path with map pins positioned along it, and stage cards floating to alternating sides connected by short leader lines.

_[tool: grep]_

_[tool: read_file]_

_[tool: str_replace_edit]_

_[tool: grep]_

_[tool: read_file]_

_[tool: str_replace_edit]_

_[tool: str_replace_edit]_

Now let me verify the page loads cleanly.

_[tool: show_html]_

_[tool: done]_

_[tool: list_files]_

_[tool: save_screenshot]_

_[tool: view_image]_

_[tool: save_screenshot]_

_[tool: view_image]_

_[tool: save_screenshot]_

_[tool: view_image]_

_[tool: view_image]_

_[tool: save_screenshot]_

The roadmap looks great. Let me check the "current" stage rendering and then verify clean.

_[tool: view_image]_

_[tool: done]_

Looking great — stage 3 is properly highlighted as "Up next" with the berry-blue pin. Let me call `done` to finalize.

_[tool: read_file]_

_[tool: str_replace_edit]_

_[tool: done]_

_[tool: fork_verifier_agent]_

Built **Roadmap.html** — the Running path stages rendered as a serpentine road, replacing the linear task list with a literal map:

- **Winding asphalt road** with dashed centerline snaking down the page through 7 stages, finish medallion at the bottom
- **Map pins** for each stage — checkmark (lavender) for done, berry-blue with pulse for "up next", muted for future
- **Stage cards** float to alternating sides with leader lines back to the road; current stage gets the accent border
- **Lavender progress fill** lights up the road behind you as stages complete
- **Mileage markers** ("MILE 0", "TEMPO BLOCK", "26.2 MI") tucked beside the road
- Confetti + toast on completion (same as the original TaskList), persists to `localStorage`

**Tweaks** (toolbar toggle): swap map pins for node circles, switch road theme between Asphalt / Lavender / Minimal, adjust curve amount, toggle mileage markers, plus reset/complete-all demo buttons.

