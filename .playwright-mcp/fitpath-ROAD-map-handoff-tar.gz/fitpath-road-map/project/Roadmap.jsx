/* global React, ReactDOM, lucide, TweaksPanel, TweakSection, TweakRadio, TweakToggle, TweakSlider, useTweaks */
/* eslint-disable */

const { useState, useEffect, useRef, useLayoutEffect, useMemo } = React;

// ---------- Path / data ----------------------------------------------------

const RUNNING_PATH = {
  id: "running",
  title: "Running",
  subtitle: "Training progression — beginner to marathon",
  icon: "activity",
  color: "#7f9ef8",
  meta: [
    { value: "26 wks", label: "Total duration" },
    { value: "7", label: "Stages" },
    { value: "Marathon", label: "End goal" },
    { value: "Intermediate", label: "Difficulty" },
  ],
};

const STAGES = [
  {
    id: 1,
    title: "Walk / run intervals",
    desc: "Alternate 1 min running with 2 min walking for 20 minutes, 3× per week. Don't go faster than a conversational pace.",
    duration: "Weeks 1–3",
    milestone: "Walk / run intervals",
    details: [
      "20-minute sessions, three non-consecutive days a week",
      "Stay at a pace where you can hold a conversation",
      "Rest day or easy walk between every run",
      "Track how many intervals you finish without breaking pace",
    ],
    links: [
      { label: "Beginner walk/run plan (PDF)", icon: "clipboard-list" },
      { label: "Why slow miles work", icon: "book-open" },
      { label: "Heart-rate zone primer", icon: "heart-pulse" },
    ],
  },
  {
    id: 2,
    title: "Build to continuous 5K",
    desc: "Gradually extend running intervals until you can run 5K (3.1 miles) without stopping.",
    duration: "Weeks 4–6",
    milestone: "Build to continuous 5K",
    details: [
      "Add 30 seconds to each running interval every other session",
      "Aim for one continuous 30-minute run by week 6",
      "Hold off on speed — finishing without walking is the goal",
    ],
    links: [
      { label: "5K base-build plan", icon: "clipboard-list" },
      { label: "Form check video", icon: "play" },
    ],
  },
  {
    id: 3,
    title: "Speed work for 5K",
    desc: "Include one tempo run and one interval session per week to improve pace and efficiency.",
    duration: "Weeks 7–9",
    milestone: "Speed work for 5K",
    details: [
      "1× tempo run — 20 minutes at comfortably hard effort",
      "1× intervals — 6×400m with 90s jog recovery",
      "Two easy runs and one long run round out the week",
    ],
    links: [
      { label: "Tempo vs threshold explained", icon: "book-open" },
      { label: "Track session walkthrough", icon: "play" },
      { label: "Pace calculator", icon: "target" },
    ],
  },
  {
    id: 4,
    title: "Build weekly mileage to 30",
    desc: "Increase total weekly distance by no more than 10% per week. Add a long run every Sunday.",
    duration: "Weeks 10–14",
    milestone: "Build weekly mileage to 30",
    details: [
      "Add no more than 10% to your weekly total each week",
      "Long run on Sunday, shortest run on Monday",
      "Schedule one cutback week every fourth week",
    ],
    links: [
      { label: "Mileage build calculator", icon: "trending-up" },
      { label: "Injury prevention checklist", icon: "shield" },
    ],
  },
  {
    id: 5,
    title: "Long run progression",
    desc: "Extend your Sunday long run by 2 miles every fortnight. Practice fueling and hydration on the move.",
    duration: "Weeks 15–20",
    milestone: "Long run progression",
    details: [
      "Add 2 miles to the long run every other week",
      "Peak at 18 miles by week 20",
      "Practice race-day fueling — 30–60g carbs per hour",
    ],
    links: [
      { label: "Long-run fueling guide", icon: "apple" },
      { label: "Hydration & electrolytes", icon: "waves" },
      { label: "Recovery protocols", icon: "moon" },
    ],
  },
  {
    id: 6,
    title: "Marathon pace blocks",
    desc: "Run 6–10 mile blocks at marathon pace inside your long run. Dial in your race nutrition and kit.",
    duration: "Weeks 21–24",
    milestone: "Marathon pace blocks",
    details: [
      "Sandwich a 6–10 mile block at goal pace inside the long run",
      "Dress-rehearse race-day kit, shoes, and fuel",
      "Lock in your goal time and split strategy",
    ],
    links: [
      { label: "Race-day kit checklist", icon: "clipboard-list" },
      { label: "Marathon pacing strategy", icon: "target" },
    ],
  },
  {
    id: 7,
    title: "Taper and race day",
    desc: "Cut volume by 30% per week for two weeks. Sharpen with short pace sessions. Show up rested.",
    duration: "Weeks 25–26",
    milestone: "Taper and race day",
    details: [
      "Drop mileage by 30% in week 25, another 50% in race week",
      "Keep a handful of short pace efforts to stay sharp",
      "Sleep, hydrate, eat carbs — don't try anything new",
    ],
    links: [
      { label: "Two-week taper plan", icon: "calendar" },
      { label: "Race-morning checklist", icon: "trophy" },
    ],
  },
];

const ENCOURAGEMENT = [
  "Great work! Keep it up!",
  "You're crushing it!",
  "Awesome progress!",
  "Fantastic effort!",
  "You got this!",
  "Incredible dedication!",
  "Champion mindset!",
  "Phenomenal work!",
];

// ---------- Geometry ------------------------------------------------------
// Canvas in arbitrary units. We pass it as SVG viewBox and use percentages
// over the same coordinate space for the HTML overlay so pins and cards stay
// glued to the road regardless of viewport scale.

const VB_W = 1100;
const VB_H = 2160;

// Stage positions in viewBox coords (zig-zag, finish on center axis at bottom).
function buildLayout(amplitude) {
  // amplitude 0..1 — controls how far stages drift from center
  const cx = VB_W / 2;
  const dx = 230 * amplitude; // 0..230
  const ys = [140, 440, 740, 1040, 1340, 1640, 1960];
  const sides = [-1, 1, -1, 1, -1, 1, 0]; // last is finish (center)
  return ys.map((y, i) => ({
    x: cx + sides[i] * dx,
    y,
    side: sides[i],          // -1 left, +1 right, 0 center
  }));
}

function buildRoadPath(points) {
  // Smooth cubic bezier through every point.
  let d = `M ${points[0].x} ${points[0].y}`;
  for (let i = 1; i < points.length; i++) {
    const p0 = points[i - 1];
    const p1 = points[i];
    const midY = (p0.y + p1.y) / 2;
    d += ` C ${p0.x} ${midY}, ${p1.x} ${midY}, ${p1.x} ${p1.y}`;
  }
  return d;
}

// ---------- Helpers --------------------------------------------------------

function toPascal(s) { return s.split("-").map(w => w[0].toUpperCase() + w.slice(1)).join(""); }
function Icon({ name, size = 18, strokeWidth = 1.5, color, style }) {
  const icon = window.lucide?.icons?.[toPascal(name)];
  if (!icon) return <span style={{ display: "inline-block", width: size, height: size, ...style }} />;
  let children;
  if (Array.isArray(icon) && icon[0] === "svg") children = icon[2];
  else if (Array.isArray(icon)) children = icon;
  if (!children) return null;
  const inner = children.map(([tag, attrs]) =>
    `<${tag} ${Object.entries(attrs).map(([k, v]) => `${k}="${v}"`).join(" ")} />`
  ).join("");
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${strokeWidth}" stroke-linecap="round" stroke-linejoin="round">${inner}</svg>`;
  return (
    <span
      style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", color: color || "currentColor", lineHeight: 0, ...style }}
      dangerouslySetInnerHTML={{ __html: svg }}
    />
  );
}

function confettiBurst(originX, originY) {
  // Full-screen confetti — pieces in every shape and color rain across the
  // entire viewport. Used for stage-completion celebrations.
  const colors = ["#aaa8ff", "#7f9ef8", "#c1cff8", "#fad0f3", "#ffffff", "#ffd89b"];
  const container = document.createElement("div");
  container.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:9999;overflow:hidden;";
  document.body.appendChild(container);
  const COUNT = 180;
  for (let i = 0; i < COUNT; i++) {
    const dot = document.createElement("div");
    const color = colors[Math.floor(Math.random() * colors.length)];
    const size = Math.random() * 12 + 6;
    // Spread launch sites across whole top of viewport for a fullscreen feel.
    const x = Math.random() * window.innerWidth;
    const y = -20 - Math.random() * 200;
    const duration = Math.random() * 1800 + 1600;
    const shape = Math.random() < 0.6 ? "50%" : Math.random() < 0.5 ? "2px" : "0";
    const sway = (Math.random() - 0.5) * 240;
    dot.style.cssText = `
      position:absolute;top:${y}px;left:${x}px;
      width:${size}px;height:${size * (Math.random() < 0.4 ? 0.4 : 1)}px;
      border-radius:${shape};
      background:${color};opacity:.95;
      --rm-sway:${sway}px;
      animation:rm-fall ${duration}ms cubic-bezier(.25,.6,.3,1) forwards;
      animation-delay:${Math.random() * 600}ms;
    `;
    container.appendChild(dot);
  }
  setTimeout(() => container.remove(), 4200);
}

// ---------- Pins ----------------------------------------------------------

function MapPin({ state, number, color = "#7f9ef8", size = 1 }) {
  // state: 'done' | 'current' | 'locked'
  const fill =
    state === "done"    ? "#aaa8ff" :
    state === "current" ? color :
                          "#2b2e3f";
  const border =
    state === "done"    ? "#c1c0ff" :
    state === "current" ? "#aac4ff" :
                          "#3b3f52";
  const w = 46 * size, h = 58 * size;
  return (
    <svg width={w} height={h} viewBox="0 0 46 58" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id={`pin-gloss-${state}-${number}`} cx="0.35" cy="0.3" r="0.7">
          <stop offset="0%" stopColor="rgba(255,255,255,0.55)" />
          <stop offset="55%" stopColor="rgba(255,255,255,0.05)" />
          <stop offset="100%" stopColor="rgba(0,0,0,0.0)" />
        </radialGradient>
      </defs>
      {/* shadow ellipse at foot */}
      <ellipse cx="23" cy="56" rx="9" ry="2" fill="rgba(0,0,0,0.45)" />
      <path
        d="M23 1.5C12.5 1.5 4 9.7 4 19.8c0 5.7 2.7 10.7 6.8 14.7 4.2 4.1 9.5 9.7 11.4 14.6.4 1 1.6 1 2 0 1.9-4.9 7.2-10.5 11.4-14.6 4.1-4 6.8-9 6.8-14.7C42.4 9.7 33.5 1.5 23 1.5Z"
        fill={fill}
        stroke={border}
        strokeWidth="1.4"
      />
      <path
        d="M23 1.5C12.5 1.5 4 9.7 4 19.8c0 5.7 2.7 10.7 6.8 14.7 4.2 4.1 9.5 9.7 11.4 14.6.4 1 1.6 1 2 0 1.9-4.9 7.2-10.5 11.4-14.6 4.1-4 6.8-9 6.8-14.7C42.4 9.7 33.5 1.5 23 1.5Z"
        fill={`url(#pin-gloss-${state}-${number})`}
      />
      <circle cx="23" cy="20" r="9.5" fill="#0c0d12" />
      {state === "done" ? (
        <path d="M17.5 20.2l3.7 3.6 7.4-7.4" stroke="#aaa8ff" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      ) : (
        <text x="23" y="24"
          textAnchor="middle"
          fontFamily="DM Sans, sans-serif"
          fontSize="11"
          fontWeight="700"
          fill={state === "current" ? color : "rgba(255,255,255,.55)"}
        >{number}</text>
      )}
    </svg>
  );
}

function NodePin({ state, number, color = "#7f9ef8" }) {
  const fill =
    state === "done"    ? "#aaa8ff" :
    state === "current" ? color :
                          "#1a1d28";
  const border =
    state === "done"    ? "#c1c0ff" :
    state === "current" ? "#aac4ff" :
                          "rgba(255,255,255,.18)";
  return (
    <svg width="48" height="48" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
      <circle cx="24" cy="24" r="20" fill={fill} stroke={border} strokeWidth="2" />
      <circle cx="24" cy="24" r="14" fill="rgba(0,0,0,0.18)" />
      {state === "done" ? (
        <path d="M16 24.2l5 5 11-11" stroke="#0c0d12" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      ) : (
        <text x="24" y="28.5"
          textAnchor="middle"
          fontFamily="DM Sans, sans-serif"
          fontSize="14"
          fontWeight="700"
          fill={state === "current" ? "#0c0d12" : "rgba(255,255,255,.55)"}
        >{number}</text>
      )}
    </svg>
  );
}

// ---------- Roadmap canvas ------------------------------------------------

function Roadmap({ stages, completed, onToggle, tweaks, started, onStart, expandedId, onExpand }) {
  const points = useMemo(() => buildLayout(tweaks.amplitude), [tweaks.amplitude]);
  const dPath = useMemo(() => buildRoadPath(points), [points]);

  const completedSet = new Set(completed);
  const firstUnfinishedIdx = stages.findIndex(s => !completedSet.has(s.id));
  const lastDoneIdx = completed.length - 1; // -1 if none

  // Road colors by theme
  const roadTheme = tweaks.roadTheme; // 'asphalt' | 'accent' | 'minimal'
  const roadColors =
    roadTheme === "accent"  ? { base: "#aaa8ff", edge: "#7066d4", dash: "rgba(255,255,255,.9)", filled: "#aaa8ff", future: "rgba(170,168,255,.22)" } :
    roadTheme === "minimal" ? { base: "#1a1d28", edge: "rgba(255,255,255,0.08)", dash: "rgba(255,255,255,.45)", filled: "#aaa8ff", future: "#1a1d28" } :
                              { base: "#0f1623", edge: "#1d2436", dash: "#dfe3ee", filled: "#aaa8ff", future: "#0f1623" };

  const roadWidth = 46;

  // Animated road progress via stroke-dashoffset.
  // We need the path's total length to compute dasharray/offset.
  const measurePathRef = useRef(null);
  const [pathLength, setPathLength] = useState(0);
  useLayoutEffect(() => {
    if (measurePathRef.current) {
      try { setPathLength(measurePathRef.current.getTotalLength()); } catch (e) {}
    }
  }, [dPath]);

  const progressFraction = completed.length / stages.length;
  const filledLength = pathLength * progressFraction;
  const dashOffset = pathLength - filledLength;

  // Detect when a new stage completes (for the head burst + shine sweep)
  const prevCountRef = useRef(completed.length);
  const [burstSeed, setBurstSeed] = useState(0);
  const [shine, setShine] = useState(null); // { from, to } in stroke-dashoffset terms
  useEffect(() => {
    const prev = prevCountRef.current;
    if (completed.length > prev && pathLength > 0) {
      const fromOff = pathLength - (prev / stages.length) * pathLength;
      const toOff   = pathLength - (completed.length / stages.length) * pathLength;
      setBurstSeed(s => s + 1);
      setShine({ from: fromOff, to: toOff, key: Date.now() });
      const t = setTimeout(() => setShine(null), 1200);
      prevCountRef.current = completed.length;
      return () => clearTimeout(t);
    }
    prevCountRef.current = completed.length;
  }, [completed.length, pathLength, stages.length]);

  // Head position — the leading point of the progress line
  const headPoint = completed.length > 0 ? points[Math.min(completed.length, stages.length) - 1] : null;

  return (
    <div className="rm-canvas-wrap">
      <div className="rm-canvas" style={{ aspectRatio: `${VB_W}/${VB_H}`, position: "relative" }}>
        {!started && (
          <div className="rm-start-gate">
            <span className="rm-start-eyebrow">Ready to begin?</span>
            <span className="rm-letsgo-pulse">
              <button className="rm-letsgo" onClick={onStart}>
                Let's go
                <svg width="18" height="18" viewBox="0 0 14 14" fill="none">
                  <path d="M3 7h8M7 3l4 4-4 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
            </span>
            <span className="rm-start-arrow" />
          </div>
        )}
        <svg className="rm-canvas-svg" viewBox={`0 0 ${VB_W} ${VB_H}`} preserveAspectRatio="xMidYMid meet">
          <defs>
            <radialGradient id="rm-finish-glow" cx="0.5" cy="0.5" r="0.5">
              <stop offset="0%" stopColor="rgba(170,168,255,0.28)"/>
              <stop offset="100%" stopColor="rgba(170,168,255,0)"/>
            </radialGradient>
            <filter id="rm-road-shadow" x="-10%" y="-10%" width="120%" height="120%">
              <feGaussianBlur in="SourceAlpha" stdDeviation="6"/>
              <feOffset dx="0" dy="3" result="off"/>
              <feComponentTransfer><feFuncA type="linear" slope="0.55"/></feComponentTransfer>
              <feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>
            </filter>
            <radialGradient id="rm-head-glow" cx="0.5" cy="0.5" r="0.5">
              <stop offset="0%"  stopColor="rgba(170,168,255,0.55)"/>
              <stop offset="60%" stopColor="rgba(170,168,255,0.18)"/>
              <stop offset="100%" stopColor="rgba(170,168,255,0)"/>
            </radialGradient>
          </defs>

          {/* Hidden measurement path — used to read getTotalLength on mount */}
          <path ref={measurePathRef} d={dPath} fill="none" stroke="none" style={{ visibility: "hidden" }} />

          {/* Base road — outer edge */}
          <path d={dPath} stroke={roadColors.edge} strokeWidth={roadWidth + 8}
                fill="none" strokeLinecap="round" strokeLinejoin="round" filter="url(#rm-road-shadow)" />
          {/* Base road — surface */}
          <path d={dPath} stroke={roadColors.base} strokeWidth={roadWidth}
                fill="none" strokeLinecap="round" strokeLinejoin="round" />

          {/* Progress overlay — same path, lavender, revealed via stroke-dashoffset */}
          {pathLength > 0 && completed.length > 0 && (
            <path
              className="rm-road-progress"
              d={dPath}
              stroke={roadColors.filled}
              strokeWidth={roadWidth}
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
              opacity="0.96"
              pathLength={pathLength}
              strokeDasharray={pathLength}
              strokeDashoffset={dashOffset}
            />
          )}

          {/* Shine sweep — a short bright segment that travels over the newly-opened road */}
          {shine && pathLength > 0 && (
            <path
              key={shine.key}
              className="rm-road-shine"
              d={dPath}
              stroke="rgba(255,255,255,0.9)"
              strokeWidth={roadWidth - 14}
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
              opacity="0.6"
              strokeDasharray={`${Math.max(60, pathLength * 0.06)} ${pathLength}`}
              style={{
                "--rm-shine-from": `${shine.from}px`,
                "--rm-shine-to":   `${shine.to}px`,
              }}
            />
          )}

          {/* Centerline dashes */}
          <path d={dPath} stroke={roadColors.dash} strokeWidth="2.2"
                fill="none" strokeLinecap="butt" strokeLinejoin="round"
                strokeDasharray="14 18" />

          {/* Soft glow under finish */}
          <circle
            cx={points[points.length - 1].x}
            cy={points[points.length - 1].y}
            r="120"
            fill="url(#rm-finish-glow)"
          />

          {/* Head glow — sits at the leading edge of the completed road */}
          {headPoint && (
            <>
              <circle
                className="rm-road-head"
                cx={headPoint.x}
                cy={headPoint.y}
                r="60"
                fill="url(#rm-head-glow)"
                opacity="0.9"
              />
              {/* burst ring when stage just completed */}
              <circle
                key={`burst-${burstSeed}`}
                className="rm-road-head-burst"
                cx={headPoint.x}
                cy={headPoint.y}
                r="26"
                fill="none"
                stroke="rgba(170,168,255,0.8)"
                strokeWidth="3"
              />
            </>
          )}
        </svg>

        {/* DOM overlay — pins, cards, finish */}
        <div className="rm-overlay">
          {stages.map((s, i) => {
            const p = points[i];
            const done = completedSet.has(s.id);
            const current = !done && i === firstUnfinishedIdx;
            const state = done ? "done" : current ? "current" : "locked";
            // Sequential lock: only the current stage can be marked complete,
            // and only the most-recently-completed stage can be un-completed.
            // First stage is additionally gated behind the "Let's go" CTA at the top.
            const baseCanToggle = (current) || (done && i === lastDoneIdx);
            const canToggle = baseCanToggle && !(current && i === 0 && !started);

            // pin position in %
            const left = (p.x / VB_W) * 100;
            const top = (p.y / VB_H) * 100;

            // card placement: opposite side of pin
            const cardSide = p.side >= 0 ? "left" : "right";
            const cardOffsetPct = 6;
            const roadHalfPct = (28 / VB_W) * 100;
            const cardWidthPct = 31;

            const isFinish = i === stages.length - 1;
            const isExpanded = expandedId === s.id;

            const pinEl = (
              <button
                key={`pin-${s.id}`}
                className={`rm-pin ${tweaks.pinStyle === "node" ? "is-node" : ""} ${state === "current" ? "is-current" : ""}`}
                style={{ left: `${left}%`, top: `${top}%`, zIndex: 5, cursor: canToggle ? "pointer" : "default" }}
                onClick={(e) => {
                  if (!canToggle) return;
                  const r = e.currentTarget.getBoundingClientRect();
                  onToggle(s.id, !done, r.left + r.width/2, r.top);
                }}
                aria-label={`${done ? "Mark incomplete" : "Mark complete"}: ${s.title}`}
              >
                {state === "current" && !(i === 0 && !started) && (
                  <span
                    className="rm-pin-pulse"
                    style={{
                      position: "absolute",
                      bottom: tweaks.pinStyle === "node" ? "50%" : 4,
                      left: "50%",
                      transform: "translate(-50%, 50%)",
                      width: 30, height: 30, borderRadius: "50%",
                      background: RUNNING_PATH.color, opacity: .55,
                      filter: "blur(2px)",
                    }}
                  />
                )}
                {tweaks.pinStyle === "node"
                  ? <NodePin state={state} number={s.id} color={RUNNING_PATH.color} />
                  : <MapPin state={state} number={s.id} color={RUNNING_PATH.color} />}
              </button>
            );

            // Milestone label = the goal title.
            const milestoneSide = cardSide === "right" ? "left" : "right";
            const milestoneEl = tweaks.showMilestones && !isFinish && (
              <div
                className={`rm-milestone ${done ? "is-done" : ""} ${current ? "is-current" : ""}`}
                style={{
                  left: milestoneSide === "left"
                    ? `${left - roadHalfPct - 2}%`
                    : `${left + roadHalfPct + 2}%`,
                  top: `${top}%`,
                  textAlign: milestoneSide === "left" ? "right" : "left",
                  transform: milestoneSide === "left"
                    ? "translate(-100%, -50%)"
                    : "translate(0, -50%)",
                }}
              >
                {s.milestone}
              </div>
            );

            if (isFinish) {
              return (
                <React.Fragment key={`row-${s.id}`}>
                  <div
                    className="rm-finish"
                    style={{ left: `${left}%`, top: `${top}%`, zIndex: 5, cursor: canToggle ? "pointer" : "default" }}
                    onClick={(e) => {
                      if (!canToggle) return;
                      const r = e.currentTarget.getBoundingClientRect();
                      onToggle(s.id, !done, r.left + r.width/2, r.top);
                    }}
                    aria-label="Mark complete: Taper and race day"
                  >
                    {done ? (
                      <>
                        <Icon name="trophy" size={28} color="#0c0d12" strokeWidth={2} />
                        <span className="rm-finish-sub" style={{ marginTop: 6 }}>Finished</span>
                      </>
                    ) : (
                      <>
                        <span className="rm-finish-label">Finish</span>
                        <span className="rm-finish-sub">26.2 mi</span>
                      </>
                    )}
                  </div>
                  <StageCard
                    stage={s}
                    state={state}
                    canToggle={canToggle}
                    expanded={isExpanded}
                    onExpand={() => onExpand(s.id)}
                    style={{
                      left: `${left}%`,
                      top: `calc(${(p.y / VB_H) * 100}% + 70px)`,
                      transform: "translateX(-50%)",
                      width: `${cardWidthPct + 4}%`,
                    }}
                    onToggle={(x, y) => onToggle(s.id, !done, x, y)}
                  />
                </React.Fragment>
              );
            }

            const cardStyle = cardSide === "right"
              ? { left: `${left + roadHalfPct + cardOffsetPct}%`, top: `${top}%`, transform: "translateY(-50%)", width: `${cardWidthPct}%` }
              : { right: `${100 - left + roadHalfPct + cardOffsetPct}%`, top: `${top}%`, transform: "translateY(-50%)", width: `${cardWidthPct}%` };

            const leaderWidthPct = cardOffsetPct - 0.5;
            const leaderStyle = cardSide === "right"
              ? { left: `${left + roadHalfPct + 0.2}%`, top: `${top}%`, width: `${leaderWidthPct}%` }
              : { left: `${left - roadHalfPct - leaderWidthPct - 0.2}%`, top: `${top}%`, width: `${leaderWidthPct}%` };

            return (
              <React.Fragment key={`row-${s.id}`}>
                <div className="rm-card-leader" style={leaderStyle} />
                <StageCard
                  stage={s}
                  state={state}
                  canToggle={canToggle}
                  expanded={isExpanded}
                  onExpand={() => onExpand(s.id)}
                  style={cardStyle}
                  onToggle={(x, y) => onToggle(s.id, !done, x, y)}
                />
                {pinEl}
                {milestoneEl}
              </React.Fragment>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function StageCard({ stage, state, canToggle, expanded, onExpand, style, onToggle }) {
  const cls = `rm-card ${state === "done" ? "is-done" : ""} ${state === "current" ? "is-current" : ""} ${state === "locked" ? "is-locked" : ""}`;
  const statusLabel =
    state === "done"    ? "Completed" :
    state === "current" ? "Up next" :
                          "Locked";

  return (
    <div className={cls} style={style}>
      <div className="rm-card-head">
        <span className="rm-card-stage">Stage {String(stage.id).padStart(2, "0")}</span>
        <span className="rm-card-pill">{stage.duration}</span>
      </div>
      <div className="rm-card-stage-row">
        <h3 className="rm-card-title">{stage.title}</h3>
      </div>

      {/* Expand toggle row — opens the stage in a modal dialog */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 8 }}>
        <span style={{ fontSize: 12, color: "var(--fp-text-muted)" }}>{statusLabel}</span>
        <button
          className="rm-card-expand"
          onClick={() => onExpand(stage.id)}
          aria-haspopup="dialog"
        >
          Details
          <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
            <path d="M5 2H2v3M7 10h3V7M2 2l3.5 3.5M10 10L6.5 6.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
      </div>

      <div className="rm-card-foot">
        <span>
          {state === "done"    ? "Completed" :
           state === "current" ? "Up next" :
                                 "Unlocks after previous stage"}
        </span>

        {canToggle ? (
          <button
            className="rm-card-action"
            onClick={(e) => {
              const r = e.currentTarget.getBoundingClientRect();
              onToggle(r.left + r.width/2, r.top);
            }}
          >
            {state === "done" ? "Mark incomplete" : "Mark complete"}
            <svg width="13" height="13" viewBox="0 0 14 14" fill="none">
              <path d="M3 7h8M7 3l4 4-4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        ) : (
          <span className="rm-card-action is-locked" aria-disabled="true">
            <svg width="13" height="13" viewBox="0 0 14 14" fill="none">
              <path d="M4 6V4.5a3 3 0 016 0V6M3.5 6h7v5h-7z" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
            </svg>
            Locked
          </span>
        )}
      </div>

      {/* Details button just signals which stage to open in the modal — no inline panel. */}
    </div>
  );
}

function StageDetailsModal({ stage, state, onClose }) {
  const isOpen = !!stage;
  useEffect(() => {
    if (!isOpen) return;
    function onKey(e) { if (e.key === "Escape") onClose(); }
    window.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const statusLabel =
    state === "done"    ? "Completed" :
    state === "current" ? "Up next" :
                          "Locked — finish the previous stage first";

  return (
    <div
      className="rm-modal-backdrop"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={`Stage ${stage.id}: ${stage.title}`}
    >
      <div className="rm-modal" onClick={(e) => e.stopPropagation()}>
        <button className="rm-modal-close" onClick={onClose} aria-label="Close">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M3 3l8 8M11 3l-8 8" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/>
          </svg>
        </button>

        <div className="rm-modal-eyebrow">
          <span className="rm-modal-stage">Stage {String(stage.id).padStart(2, "0")}</span>
          <span className="rm-card-pill">{stage.duration}</span>
          <span style={{ fontSize: 12, color: "var(--fp-text-muted)" }}>· {statusLabel}</span>
        </div>

        <h2 className="rm-modal-title">{stage.title}</h2>
        <p className="rm-modal-desc">{stage.desc}</p>

        {stage.details?.length > 0 && (
          <div className="rm-modal-section">
            <p className="rm-card-section-label">What you'll do</p>
            <ul className="rm-card-bullets">
              {stage.details.map((d, idx) => <li key={idx}>{d}</li>)}
            </ul>
          </div>
        )}

        {stage.links?.length > 0 && (
          <div className="rm-modal-section">
            <p className="rm-card-section-label">More on this stage</p>
            <div className="rm-card-links">
              {stage.links.map((l, idx) => (
                <button key={idx} className="rm-card-link" type="button">
                  <span className="rm-card-link-icon">
                    <Icon name={l.icon} size={14} strokeWidth={1.7} />
                  </span>
                  <span>{l.label}</span>
                  <span className="rm-card-link-arrow">
                    <svg width="13" height="13" viewBox="0 0 14 14" fill="none">
                      <path d="M3 7h8M7 3l4 4-4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ---------- Nav / Hero / Progress -----------------------------------------

function Nav() {
  return (
    <header className="rm-nav">
      <a className="rm-brand">
        <span className="rm-brand-tile">
          <Icon name="dumbbell" size={18} color="#0c0d12" strokeWidth={2} />
        </span>
        fitpath
      </a>
      <nav className="rm-nav-links">
        <a>Home</a>
        <a className="active">Paths</a>
        <a>Dashboard</a>
        <a>About</a>
      </nav>
    </header>
  );
}

function Hero({ path, completed, total }) {
  const pct = Math.round((completed / total) * 100);
  return (
    <section className="rm-hero">
      <div className="rm-hero-orb" />
      <div className="rm-container" style={{ position: "relative", zIndex: 1 }}>
        <a className="rm-back">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M8 3L4 7l4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          All paths
        </a>
        <div className="rm-hero-row">
          <div className="rm-hero-icon" style={{ background: `${path.color}18`, border: `1px solid ${path.color}30`, color: path.color }}>
            <Icon name={path.icon} size={32} color={path.color} strokeWidth={1.5} />
          </div>
          <div style={{ flex: 1, minWidth: 280 }}>
            <div className="rm-eyebrow">Training path · By sport</div>
            <h1 className="rm-hero-title">
              {path.title} <em>roadmap.</em>
            </h1>
            <p className="rm-hero-desc">{path.subtitle}. Seven progressive stages drawn out like a road — pick up exactly where you left off.</p>
          </div>
        </div>
        <div className="rm-meta">
          {path.meta.map(m => (
            <div className="rm-meta-item" key={m.label}>
              <p>{m.value}</p>
              <p>{m.label}</p>
            </div>
          ))}
        </div>
        <div className="rm-progress-strip">
          <div className="rm-progress-head">
            <span className="rm-progress-label">Your progress</span>
            <span className="rm-progress-stats">{completed} / {total} ({pct}%)</span>
          </div>
          <div className="rm-progress-track">
            <div className="rm-progress-fill" style={{ width: `${pct}%` }} />
          </div>
        </div>
      </div>
    </section>
  );
}

// ---------- Celebration overlay -------------------------------------------

const CELEBRATE_MESSAGES = [
  { title: "You crushed it!",     sub: "One stage closer to the finish line.", emoji: "trophy" },
  { title: "Look at you go!",     sub: "Every mile compounds. Keep stacking.", emoji: "sparkles" },
  { title: "That's the work.",    sub: "Discipline beats motivation. You showed up.", emoji: "flame" },
  { title: "Stage cleared.",      sub: "The road keeps opening up for you.",   emoji: "check-circle-2" },
  { title: "Phenomenal effort!",  sub: "Recovery now, hard work next.",        emoji: "medal" },
  { title: "Eyes up — keep going.", sub: "You're closer than you were yesterday.", emoji: "target" },
];

function CelebrationOverlay({ stage, completedCount, totalCount, onClose }) {
  // Pick a message variant per celebration — keyed on completedCount so the
  // message is stable for the duration of the overlay but rotates across runs.
  const variant = useMemo(() => {
    if (!stage) return null;
    return CELEBRATE_MESSAGES[completedCount % CELEBRATE_MESSAGES.length];
  }, [completedCount, stage]);

  useEffect(() => {
    if (!stage) return;
    function onKey(e) { if (e.key === "Escape") onClose(); }
    window.addEventListener("keydown", onKey);
    // Auto-dismiss after 10s.
    const t = setTimeout(onClose, 10000);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      clearTimeout(t);
      document.body.style.overflow = prevOverflow;
    };
  }, [stage, onClose]);

  if (!stage || !variant) return null;

  const isFinal = completedCount === totalCount;
  const title = isFinal ? "Marathon complete!" : variant.title;
  const sub   = isFinal ? "26.2 miles. You did the whole thing." : variant.sub;
  const badge = isFinal ? "trophy" : variant.emoji;

  return (
    <div className="rm-celebrate" onClick={onClose} role="dialog" aria-modal="true">
      <div className="rm-celebrate-card" onClick={(e) => e.stopPropagation()}>
        <span className="rm-celebrate-dismiss">Tap anywhere to dismiss</span>
        <div className="rm-celebrate-badge">
          <Icon name={badge} size={42} color="#0c0d12" strokeWidth={2} />
        </div>
        <p className="rm-celebrate-eyebrow">Stage {String(stage.id).padStart(2, "0")} complete</p>
        <h2 className="rm-celebrate-title">
          {title.split(" ").slice(0, -1).join(" ")} <em>{title.split(" ").slice(-1)}</em>
        </h2>
        <p className="rm-celebrate-stage-name">
          <strong>{stage.title}</strong> · {stage.duration}
        </p>
        <p className="rm-celebrate-sub">{sub}</p>
        <div className="rm-celebrate-progress">
          <span className="rm-celebrate-progress-label">Progress</span>
          <span className="rm-celebrate-progress-stat">
            {completedCount}<span style={{ color: "var(--fp-text-muted)" }}> / {totalCount} stages</span>
          </span>
        </div>
        <div className="rm-celebrate-timer">
          <div className="rm-celebrate-timer-bar" />
        </div>
      </div>
    </div>
  );
}

// ---------- Toast (legacy, unused) ----------------------------------------

function Toast({ message }) {
  if (!message) return null;
  return (
    <div style={{
      position: "fixed", top: 24, right: 24,
      background: "var(--fp-surface)",
      border: "1px solid var(--fp-border-2)",
      borderRadius: 14,
      padding: "14px 20px",
      boxShadow: "0 8px 32px rgba(0,0,0,.4)",
      zIndex: 1000,
      animation: "rm-toast-in .3s ease",
      minWidth: 220,
    }}>
      <p style={{ fontWeight: 700, fontSize: 14, color: "var(--fp-white)", margin: 0 }}>Stage complete!</p>
      <p style={{ fontSize: 13, color: "var(--fp-text-muted)", margin: "2px 0 0" }}>{message}</p>
    </div>
  );
}

// ---------- App -----------------------------------------------------------

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "pinStyle": "pin",
  "roadTheme": "asphalt",
  "amplitude": 0.95,
  "showMilestones": true
}/*EDITMODE-END*/;

function App() {
  const [completed, setCompleted] = useState([]);
  const [started, setStarted] = useState(false);
  const [expandedId, setExpandedId] = useState(null);
  const [celebrateStage, setCelebrateStage] = useState(null);
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Hydrate from localStorage.
  useEffect(() => {
    try {
      const raw = localStorage.getItem(`fitpath_progress_${RUNNING_PATH.id}`);
      if (raw) {
        const parsed = JSON.parse(raw);
        setCompleted(parsed);
        if (parsed.length > 0) setStarted(true);
      }
    } catch (e) {}
    try {
      if (localStorage.getItem(`fitpath_started_${RUNNING_PATH.id}`) === "1") {
        setStarted(true);
      }
    } catch (e) {}
  }, []);

  // Persist on change
  useEffect(() => {
    try {
      localStorage.setItem(`fitpath_progress_${RUNNING_PATH.id}`, JSON.stringify(completed));
    } catch (e) {}
  }, [completed]);

  useEffect(() => {
    try {
      localStorage.setItem(`fitpath_started_${RUNNING_PATH.id}`, started ? "1" : "0");
    } catch (e) {}
  }, [started]);

  function toggle(stageId, willComplete, originX, originY) {
    // Sequential lock: only allow completing the current stage (first undone)
    // and only allow uncompleting the most recently completed stage.
    if (willComplete) {
      const firstUndoneIdx = STAGES.findIndex(s => !completed.includes(s.id));
      if (firstUndoneIdx === -1) return;
      if (STAGES[firstUndoneIdx].id !== stageId) return; // not the current one
      if (firstUndoneIdx === 0 && !started) return;      // must press "Let's go" first

      confettiBurst(originX, originY);
      // Fullscreen celebration overlay — auto-dismisses after 10s or on click.
      setCelebrateStage(STAGES[firstUndoneIdx]);
      setCompleted(prev => prev.includes(stageId) ? prev : [...prev, stageId]);
    } else {
      const lastDoneId = completed[completed.length - 1];
      if (stageId !== lastDoneId) return; // can only undo the last one
      setCompleted(prev => prev.filter(id => id !== stageId));
    }
  }

  function handleStart() {
    setStarted(true);
    // small celebration cue at the first pin location
    const firstPin = document.querySelector(".rm-pin");
    if (firstPin) {
      const r = firstPin.getBoundingClientRect();
      confettiBurst(r.left + r.width / 2, r.top);
    }
  }

  function resetProgress() {
    setCompleted([]);
    setStarted(false);
    setExpandedId(null);
  }
  function completeAll() {
    setCompleted(STAGES.map(s => s.id));
    setStarted(true);
    confettiBurst(window.innerWidth / 2, 100);
  }

  return (
    <>
      <div className="rm-container">
        <Nav />
      </div>
      <Hero path={RUNNING_PATH} completed={completed.length} total={STAGES.length} />
      <section className="rm-section">
        <div className="rm-container">
          <div className="rm-section-head">
            <div>
              <h2 className="rm-section-title">Your <em>road</em> to 26.2.</h2>
              <p className="rm-section-sub">Tap any pin to log a stage. Your progress lights up the road behind you.</p>
            </div>
            <div className="rm-legend">
              <span className="rm-legend-item">
                <span className="rm-legend-dot" style={{ background: "#aaa8ff" }} /> Done
              </span>
              <span className="rm-legend-item">
                <span className="rm-legend-dot" style={{ background: RUNNING_PATH.color }} /> Up next
              </span>
              <span className="rm-legend-item">
                <span className="rm-legend-dot" style={{ background: "#2b2e3f" }} /> Future
              </span>
            </div>
          </div>

          <Roadmap
            stages={STAGES}
            completed={completed}
            onToggle={toggle}
            tweaks={tweaks}
            started={started}
            onStart={handleStart}
            expandedId={expandedId}
            onExpand={(id) => setExpandedId(prev => prev === id ? null : id)}
          />
        </div>
      </section>

      <Toast message={null /* replaced by CelebrationOverlay */} />

      <CelebrationOverlay
        stage={celebrateStage}
        completedCount={completed.length}
        totalCount={STAGES.length}
        onClose={() => setCelebrateStage(null)}
      />

      <StageDetailsModal
        stage={expandedId ? STAGES.find(s => s.id === expandedId) : null}
        state={
          expandedId == null ? null :
          completed.includes(expandedId) ? "done" :
          (STAGES.findIndex(s => !completed.includes(s.id)) === STAGES.findIndex(s => s.id === expandedId) ? "current" : "locked")
        }
        onClose={() => setExpandedId(null)}
      />

      <TweaksPanel>
        <TweakSection label="Pin style">
          <TweakRadio
            label="Marker"
            value={tweaks.pinStyle}
            onChange={(v) => setTweak("pinStyle", v)}
            options={[
              { value: "pin", label: "Map pin" },
              { value: "node", label: "Node" },
            ]}
          />
        </TweakSection>
        <TweakSection label="Road">
          <TweakRadio
            label="Theme"
            value={tweaks.roadTheme}
            onChange={(v) => setTweak("roadTheme", v)}
            options={[
              { value: "asphalt", label: "Asphalt" },
              { value: "accent", label: "Lavender" },
              { value: "minimal", label: "Minimal" },
            ]}
          />
          <TweakSlider
            label="Curve"
            value={tweaks.amplitude}
            min={0.3} max={1.2} step={0.05}
            onChange={(v) => setTweak("amplitude", v)}
          />
          <TweakToggle
            label="Mileage markers"
            value={tweaks.showMilestones}
            onChange={(v) => setTweak("showMilestones", v)}
          />
        </TweakSection>
        <TweakSection label="Demo">
          <div style={{ display: "flex", gap: 8, padding: "4px 0" }}>
            <button onClick={resetProgress} style={demoBtn}>Reset</button>
            <button onClick={completeAll} style={demoBtn}>Complete all</button>
          </div>
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

const demoBtn = {
  flex: 1, padding: "8px 12px",
  background: "var(--fp-surface-2)", color: "var(--fp-text)",
  border: "1px solid var(--fp-border-2)", borderRadius: 8,
  fontSize: 12, fontWeight: 600, cursor: "pointer",
  fontFamily: "var(--fp-font-sans)",
};

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
